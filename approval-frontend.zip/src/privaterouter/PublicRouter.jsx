import React from 'react'

const PublicRouter = ({ children }) => {
    return children;
}

export default PublicRouter;